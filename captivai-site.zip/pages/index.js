export default function Home() {
  return (
    <main>
      <h1>Welcome to CaptivAI</h1>
      <p>Build Smarter. Market Faster.</p>
    </main>
  )
}
