# CaptivAI Site

This is the official site for CaptivAI, built with Next.js.